package ImageManagementTool;

public interface ConvertImageFormat {
}
